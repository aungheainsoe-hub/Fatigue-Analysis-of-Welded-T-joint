%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Drawing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%figure(1)
DrawingLimits=[min(X0mat(:,1))-1 max(X0mat(:,1))+1 min(X0mat(:,2))-1 max(X0mat(:,2))+1 -1 1];
% 
ScaleDisp=1;                          % just to scale displacement for visualization. If want to see realistic, use 1.

%Undeformed with node numbering. 
figure(1)
%DrawMeshQ4(X0mat,ElemNodeConnectivity,zeros(length(ugloball),1),DofsAtNode,DrawingLimits,'b')             % initial conf
% Node numbering
%Writes nodal indeces in the figure
%for ii=1:NumberOfNodes,
%   text(X0mat(ii,1),X0mat(ii,2),0, int2str(ii));            
%end

VisualiseMeshQ4(X0mat,ElemNodeConnectivity,[],1,false,...
    true,true,[],[],'Reference mesh with node and element numbering');


% Visualise field you want
figure(2)
VisualiseField(ElemDOFsConnectivity,ElemNodeConnectivity,NumberOfElems,E,nu,Lz,X0vec,ugloball,Field)

% Stress fields
figure(3)
tiledlayout(2,2)

nexttile
VisualiseField(ElemDOFsConnectivity,ElemNodeConnectivity,NumberOfElems,E,nu,Lz,X0vec,ugloball,"sigma_xx")
title('\sigma_{xx}')

nexttile
VisualiseField(ElemDOFsConnectivity,ElemNodeConnectivity,NumberOfElems,E,nu,Lz,X0vec,ugloball,"sigma_yy")
title('\sigma_{yy}')

nexttile
VisualiseField(ElemDOFsConnectivity,ElemNodeConnectivity,NumberOfElems,E,nu,Lz,X0vec,ugloball,"sigma_xy")
title('\sigma_{xy}')

nexttile
VisualiseField(ElemDOFsConnectivity,ElemNodeConnectivity,NumberOfElems,E,nu,Lz,X0vec,ugloball,"sigma_vm")
title('Von Mises \sigma_{vm} (Plain stress)')


% % Analytical solution
% Iz=W*H^3/12;
% A=W*H;
% kappaxy=6/5;
% nu=0.3;
% G=E/(2*(1+nu));
% deltamax=F*L^3/(3*E*Iz)+kappaxy*F*L/(G*A)