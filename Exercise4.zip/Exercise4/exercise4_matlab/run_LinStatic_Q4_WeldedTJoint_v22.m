% ------------------------------------------------------------
% FEABody – Simple educational and research-oriented framework 
% for mechanical system simulation 
%
% Version: 0.1 (MATLAB implementation)
% Module: Linear analysis – Q4 plane stress fatigue example
% ------------------------------------------------------------
%
% Author: Marko Matikainen
% Institution: LUT University, Finland
% Year: 2026
%
% -------------------------------------------------------------------------
% Educational code philosophy
%
% This code is intentionally kept as simple and student-friendly as possible.
% Only basic programming structures are used to make the finite element
% formulation and solution procedure easy to follow.
%
% The implementation is not optimized for performance or large-scale use.
% More advanced research-oriented versions of FEABody are developed for
% such purposes.
%
% If you notice errors or have suggestions for improvements, please contact
% the author.
% -------------------------------------------------------------------------
%
% FEABody uses a dual notation:
%
% Global level:
%   DOF-based notation is used for assembly, boundary conditions,
%   loading, and the global solution process.
%
% Element level:
%   Configuration-based notation is used for element geometry,
%   kinematics, and constitutive computations.
%
% In this code:
%   X0mat = reference nodal coordinates matrix
%   X0vec = same coordinates in global DOF ordering
%   uglob = global displacement vector
%
% Course: BK80A2520 Advanced Finite Element Methods 
%         in Solid and Structural Mechanics
%
% This code is intended for educational and research purposes and is not a
% general-purpose finite element solver.
%
% Licensed under the BSD 3-Clause License.
% See the LICENSE file in the repository for full license text.
% ------------------------------------------------------------


%% Fatigue exercise template
% Linear plane stress FE analysis of a welded T-joint using Q4 elements.
% The model exploits symmetry.
%
% This MATLAB template is intentionally simplified and tailored
% for the purposes of the course exercise.
%
%   Element definition:
%
%          N4     N3      
%          
%           o-----o
%           |     |     
%           |     |     
%           o-----o
%
%          N1     N2      
%
% Units:
%   Length : mm
%   Force  : N
%   Stress : MPa (= N/mm^2)

clear;
close all;
clc;
format long;

%% Material and geometry
E  = 210000;   % Young's modulus [MPa]
nu = 0.3;      % Poisson's ratio [-]
H  = 50;       % Characteristic height [mm]
W  = 5;        % Thickness in z-direction [mm]
Lz = W;        % Thickness used in the 2D plane stress formulation [mm]
T = 1;         % 2D thickness assumed to be 1 [mm]

%% External load
q = 200;       % Applied traction / stress-like load [N/mm^2]
F = -1 * W * q; % Total force [N]

%% Element and mesh parameters
DofsAtNode = 2;                    % Two DOFs at every node: ux, uy
ElemNodes  = 4;                    % Number of nodes in Q4 element
LocalSize  = ElemNodes*DofsAtNode; % Element matrix size (4 nodes x 2 DOFs)

% Mesh input. The mesh can be generated using preprocessors of various finite element software packages,
% or with dedicated mesh generators such as Gmsh.
MeshName = 'HS_VERKKO_V3';

NLIST = readmatrix(sprintf('NLIST_%s.txt',MeshName));
ELIST = readmatrix(sprintf('ELIST_%s.txt',MeshName));

% Nodal coordinates in the initial configuration
X0mat(:,1:2) = NLIST(:,2:3);

% Element connectivity matrix: [n1 n2 n3 n4]
ElemNodeConnectivity = ELIST(:,2:5);

% Check that the element connectivity uses a proper node ordering
CheckElementConnectivityMatrixQ4(ElemNodeConnectivity,NLIST);

%% Basic dimensions
NumberOfElems    = size(ElemNodeConnectivity,1);
NumberOfNodes    = size(X0mat,1);
NumberOfAllDofs  = DofsAtNode*NumberOfNodes; % Number of all DOFs in the structure

%% DOF connectivity
% Create element DOF connectivity matrix
ElemDOFsConnectivity = ElemDOFsConnectivity_Q4(ElemNodeConnectivity,NumberOfElems);

%% Boundary conditions
% bc = 1 -> free DOF
% bc = 0 -> constrained DOF
bc = logical(ones(1,NumberOfAllDofs));

% Symmetry boundary condition at x = 0:
% all nodes on the symmetry line have ux = 0
bcNodeIDsSymX = FindGlobNodeID_v10(X0mat(:,1),0);
bcDofIDsSymX  = DofID(DofsAtNode,bcNodeIDsSymX,[1]);

% One additional y-DOF is fixed to remove rigid body motion
bcDofIDsSymY = DofID(DofsAtNode,bcNodeIDsSymX(1),[2]);

% Apply constraints
bc(bcDofIDsSymX) = 0;
bc(bcDofIDsSymY) = 0;

DOF = sum(bc);  % Number of unconstrained DOFs

%% Applied load
% Find nodes at the loaded end and distribute the total force equally
AppliedForceNodeIDs = FindGlobNodeID_BetweenCoordinates_v10(X0mat,-60);
AppliedForceDofIDs  = DofID(DofsAtNode,AppliedForceNodeIDs,[1]);

%% Initialization
Kglob = zeros(NumberOfAllDofs,NumberOfAllDofs);
fglob = zeros(NumberOfAllDofs,1);
uglob = zeros(NumberOfAllDofs,1);

% Distribute the total force equally to the selected DOFs
fglob(AppliedForceDofIDs) = F/length(AppliedForceDofIDs);

% Reshape nodal coordinates into vector form for element-wise extraction
X0vec = reshape(X0mat',[],1);

%% Assembly of the global stiffness matrix
for ii = 1:NumberOfElems
    
    % Element nodal coordinates Xe in the reference configuration
    Xe = X0vec(ElemDOFsConnectivity(ii,:));
    
    % Local element stiffness matrix for Q4 plane stress element
    Kloc = KlocQ4pstressR_SmallStrainTensor_v10(Xe,E,nu,Lz);
    
    % Assembly to the global stiffness matrix
    for jj = 1:LocalSize
        ind01 = ElemDOFsConnectivity(ii,jj);
        for kk = 1:LocalSize
            ind02 = ElemDOFsConnectivity(ii,kk);
            Kglob(ind01,ind02) = Kglob(ind01,ind02) + Kloc(jj,kk);
        end
    end
end

%% Apply boundary conditions
% Eliminate constrained DOFs using the logical bc-vector
Kglobred = Kglob(bc,bc);
fglobred = fglob(bc);

%% Solve nodal displacements
uglobred = Kglobred\fglobred;

% Gather all displacements, including constrained DOFs
ugloball = zeros(NumberOfAllDofs,1);
ugloball(bc) = uglobred;


%% Post-processing
% Visualise selected field
Field = "u_total";   % options: "ux", "uy", "u_total", "sigma_xx", "sigma_yy", "sigma_xy", "sigma_vm"
PostProcessing_v20;

%% Node stress analysis
fieldName = "sigma_vm";   % options: "sigma_xx", "sigma_yy", "sigma_xy", "sigma_vm"

% For a single node:
% NodeID = 518;
% StressData = NodeStressAnalysis(NodeID,fieldName,...
%     ElemNodeConnectivity,ElemDOFsConnectivity,...
%     X0vec,ugloball,E,nu,Lz,X0mat,true);

% For multiple nodes:
NodeIDs = 518:528;

StressResults = NodeStressAnalysisMultiple(NodeIDs,fieldName,...
    ElemNodeConnectivity,ElemDOFsConnectivity,...
    X0vec,ugloball,E,nu,Lz,X0mat,false);

VisualiseMultipleNodesAndConnectedElements(NodeIDs,X0mat,ElemNodeConnectivity,...
    'ShowElementIDs',true,...
    'ShowNodeIDs',true);